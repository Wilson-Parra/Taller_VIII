package model.repository;

import model.Category;
import model.Product;

import java.sql.SQLException;

public class TestProductRepositoryImpl {
    public static void main(String[] args) throws SQLException {
        // Crear un objeto Category válido
        Category category = new Category();
        category.setCategory_id(1); // Reemplaza con el ID de la categoría existente en tu base de datos
        category.setCategory_name("Electrónicos"); // Reemplaza con el nombre de la categoría

        // Crear un objeto Product y asignar la categoría
        Product product = new Product();
        product.setProduct_name("Producto 1");
        product.setProduct_value(100.0f);
        product.setCategory(category); // Asignar la categoría al producto

        // Llamar al método saveObj() en el repositorio
        Repository<Product> repository = new ProductRepositoryImpl();
        int rowsAffected = repository.saveObj(product);
        System.out.println("Filas afectadas: " + rowsAffected);
    }
}
