package controller;

import model.Category;
import model.Product;
import model.repository.CategoryRepositoryImpl;
import model.repository.ProductRepositoryImpl;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

@WebServlet("/product/register")
public class ProductRegisterServlet extends HttpServlet {
    private final ProductRepositoryImpl productRepository;
    private final CategoryRepositoryImpl categoryRepository;

    public ProductRegisterServlet() {
        this.productRepository = new ProductRepositoryImpl();
        this.categoryRepository = new CategoryRepositoryImpl();
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        try {
            List<Category> categories = categoryRepository.listAllObj();
            request.setAttribute("categories", categories);
            request.getRequestDispatcher("/product_register.jsp").forward(request, response);
        } catch (SQLException e) {
            e.printStackTrace();
            response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String productName = request.getParameter("product_name");
        float productValue = Float.parseFloat(request.getParameter("product_value"));
        int categoryId = Integer.parseInt(request.getParameter("category_id"));

        try {
            Category category = categoryRepository.byIdObj(categoryId);
            Product product = new Product(productName, productValue, category);


            productRepository.saveObj(product);

            response.sendRedirect(request.getContextPath() + "/product/list");
        } catch (SQLException e) {
            e.printStackTrace();
            response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
        }
    }
}
